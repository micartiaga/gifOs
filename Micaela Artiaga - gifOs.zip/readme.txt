GifOs
Proyecto 2 de ACAMICA

Creado por Micaela Artiaga con fines educativos

El objetivo de este proyecto es crear una aplicación web que haga peticiones a una API implementada por Giphy.
